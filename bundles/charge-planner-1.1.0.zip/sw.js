const SHELL = ["/","/index.html","/manifest.webmanifest","/icon.svg","/icon-192.png","/icon-512.png","/assets/index-CzS7m8Q1.css","/assets/index-DGSJY9IJ.js","/assets/web-0eEMp6yP.js","/assets/web-BjE8pTe5.js","/assets/web-BmgFtL5T.js","/assets/web-Ch25aK1y.js","/assets/web-DobHJ15d.js","/assets/web-gQkxw-Ng.js"];
const CACHE = 'scp-shell-' + "/assets/index-CzS7m8Q1.css|/assets/index-DGSJY9IJ.js|/assets/web-0eEMp6yP.js|/assets/web-BjE8pTe5.js|/assets/web-BmgFtL5T.js|/assets/web-Ch25aK1y.js|/assets/web-DobHJ15d.js|/assets/web-gQkxw-Ng.js";
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('notificationclick', event => { event.notification.close(); event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windows => windows.length ? windows[0].focus() : self.clients.openWindow('/'))); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET') return;
  if (url.origin === self.location.origin) {
    event.respondWith(fetch(event.request).catch(() => caches.match(event.request, { ignoreVary: true }).then(hit => hit || (event.request.mode === 'navigate' ? caches.match('/index.html', { ignoreVary: true }) : Response.error()))));
  } else if (url.hostname === 'tile.openstreetmap.org') {
    event.respondWith(caches.open(CACHE).then(async cache => {
      const hit = await cache.match(event.request);
      if (hit) return hit;
      const response = await fetch(event.request);
      if (response.ok || response.type === 'opaque') {
        await cache.put(event.request, response.clone());
        const keys = (await cache.keys()).filter(key => key.url.includes('tile.openstreetmap.org'));
        if (keys.length > 300) await cache.delete(keys[0]);
      }
      return response;
    }));
  }
});